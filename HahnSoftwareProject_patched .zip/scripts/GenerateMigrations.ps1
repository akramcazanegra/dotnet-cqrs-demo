dotnet tool update --global dotnet-ef
dotnet ef migrations add InitialCreate --project src/Infrastructure --startup-project src/API --output-dir Persistence/Migrations
dotnet ef database update --project src/Infrastructure --startup-project src/API