using Xunit;
using Application.Validators;

public class CreateApplicantValidatorTests
{
    [Fact]
    public void Should_Fail_When_Name_Is_Empty()
    {
        var v = new CreateApplicantValidator();
        var result = v.Validate(new Application.Commands.CreateApplicantCommand { Name = "" });
        Assert.False(result.IsValid);
    }
}