using Domain.Entities;
using Xunit;

namespace UnitTests;

public class ApplicantTests
{
    [Fact]
    public void CreateApplicant_RaisesDomainEvent()
    {
        var a = new Applicant("Akram","akram@example.com",3);
        Assert.NotNull(a);
    }
}