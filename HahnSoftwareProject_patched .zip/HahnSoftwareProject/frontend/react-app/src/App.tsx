import React, { useState } from 'react';
import axios from 'axios';

function App() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [experience, setExperience] = useState(0);

  const handleSubmit = async () => {
    const response = await axios.post('http://localhost:5000/api/applicant', {
      name,
      email,
      experienceYears: experience
    });
    alert('Applicant created: ' + response.data.id);
  };

  return (
    <div>
      <h1>Hahn Software .NET Test</h1>
      <input placeholder="Name" onChange={e => setName(e.target.value)} />
      <input placeholder="Email" onChange={e => setEmail(e.target.value)} />
      <input type="number" placeholder="Experience" onChange={e => setExperience(Number(e.target.value))} />
      <button onClick={handleSubmit}>Create Applicant</button>
    </div>
  );
}

export default App;
