# Hahn Software .NET Developer Test Project

## Setup

1. Clone repo
2. Build Docker containers:
