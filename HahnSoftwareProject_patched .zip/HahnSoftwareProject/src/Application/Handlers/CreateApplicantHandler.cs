using Domain.Entities;
using Infrastructure.Persistence;

namespace Application.Handlers
{
    public class CreateApplicantHandler
    {
        private readonly AppDbContext _context;

        public CreateApplicantHandler(AppDbContext context)
        {
            _context = context;
        }

        public async Task<Applicant> Handle(CreateApplicantCommand command)
        {
            var applicant = new Applicant(command.Name, command.Email, command.ExperienceYears);
            _context.Applicants.Add(applicant);
            await _context.SaveChangesAsync();
            return applicant;
        }
    }
}
