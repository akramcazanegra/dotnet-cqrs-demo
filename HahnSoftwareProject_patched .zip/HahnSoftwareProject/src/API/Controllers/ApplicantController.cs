using Microsoft.AspNetCore.Mvc;
using Application.Commands;
using Application.Handlers;

[ApiController]
[Route("api/[controller]")]
public class ApplicantController : ControllerBase
{
    private readonly CreateApplicantHandler _handler;

    public ApplicantController(CreateApplicantHandler handler)
    {
        _handler = handler;
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateApplicantCommand command)
    {
        var applicant = await _handler.Handle(command);
        return Ok(applicant);
    }
}
