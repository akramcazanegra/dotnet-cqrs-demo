namespace Domain.Entities
{
    public class Applicant
    {
        public Guid Id { get; private set; }
        public string Name { get; private set; }
        public string Email { get; private set; }
        public int ExperienceYears { get; private set; }

        public event Action<Applicant>? ApplicantCreated;

        public Applicant(string name, string email, int experienceYears)
        {
            Id = Guid.NewGuid();
            Name = name;
            Email = email;
            ExperienceYears = experienceYears;
            ApplicantCreated?.Invoke(this);
        }

        public void UpdateExperience(int years)
        {
            ExperienceYears = years;
        }
    }
}
