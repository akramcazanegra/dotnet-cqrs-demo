using Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Persistence
{
    public class AppDbContext : DbContext
{
    private readonly DomainEventsInterceptor _domainEventsInterceptor;

        
        // Ensure interceptor is available
 }
        public DbSet<Applicant> Applicants { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Applicant>().HasKey(a => a.Id);
            base.OnModelCreating(modelBuilder);
        }
    }
}
