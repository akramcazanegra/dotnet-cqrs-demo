const BASE = (import.meta as any).env.VITE_API ?? 'http://localhost:5000';

export async function getApplicants(){
  const res = await fetch(`${BASE}/api/applicants`);
  return await res.json();
}
export async function createApplicant(payload:any){
  const res = await fetch(`${BASE}/api/applicants`, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify(payload)
  });
  return await res.json();
}