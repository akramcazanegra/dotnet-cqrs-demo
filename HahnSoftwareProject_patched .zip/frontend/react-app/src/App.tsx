import { useEffect, useState } from 'react'
import { getApplicants, createApplicant } from './api/applicants'

export default function App() {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [exp, setExp] = useState(0)
  const [items, setItems] = useState<any[]>([])

  useEffect(() => { getApplicants().then(setItems) }, [])

  const add = async () => {
    await createApplicant({ name, email, experienceYears: exp })
    setItems(await getApplicants())
    setName(''); setEmail(''); setExp(0)
  }

  return (
    <div style={{maxWidth: 640, margin: '40px auto', fontFamily: 'sans-serif'}}>
      <h2>Applicants</h2>
      <div style={{display:'grid', gap:8}}>
        <input placeholder="Name" value={name} onChange={e=>setName(e.target.value)} />
        <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input type="number" placeholder="Experience Years" value={exp} onChange={e=>setExp(parseInt(e.target.value||'0'))} />
        <button onClick={add}>Add</button>
      </div>
      <ul>
        {items.map(x => <li key={x.id}>{x.name} — {x.email} — {x.experienceYears}y</li>)}
      </ul>
    </div>
  )
}