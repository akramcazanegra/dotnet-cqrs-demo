namespace Domain.Events
{
    public record ApplicantCreatedEvent(Guid ApplicantId, string Email);
}