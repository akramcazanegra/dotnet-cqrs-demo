using Domain.Primitives;
using Domain.Events;

namespace Domain.Entities
{
    public class Applicant : Entity
    {
        public Guid Id { get; private set; } = Guid.NewGuid();
        public string Name { get; private set; }
        public string Email { get; private set; }
        public int ExperienceYears { get; private set; }

        private Applicant() { } // EF
        public Applicant(string name, string email, int experienceYears)
        {
            Name = name;
            Email = email;
            ExperienceYears = experienceYears;
            RaiseDomainEvent(new ApplicantCreatedEvent(Id, Email));
        }

        public void UpdateExperience(int years) => ExperienceYears = years;
    }
}