namespace Application.Queries
{
    public record GetApplicantsQuery();
}