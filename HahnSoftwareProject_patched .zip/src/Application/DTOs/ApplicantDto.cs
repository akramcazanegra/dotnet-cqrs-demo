namespace Application.DTOs
{
    public record ApplicantDto(Guid Id, string Name, string Email, int ExperienceYears);
}