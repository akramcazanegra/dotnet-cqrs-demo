namespace Application.Commands
{
    public record CreateApplicantCommand(string Name, string Email, int ExperienceYears);
}