using Application.Commands;
using FluentValidation;

namespace Application.Validators
{
    public class CreateApplicantValidator : AbstractValidator<CreateApplicantCommand>
    {
        public CreateApplicantValidator()
        {
            RuleFor(x => x.Name).NotEmpty().MaximumLength(100);
            RuleFor(x => x.Email).NotEmpty().EmailAddress();
            RuleFor(x => x.ExperienceYears).GreaterThanOrEqualTo(0).LessThanOrEqualTo(50);
        }
    }
}