using Application.Commands;
using Application.DTOs;
using Application.Queries;
using Domain.Entities;
using Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Application.Handlers
{
    public class ApplicantCommandHandler
    {
        private readonly AppDbContext _db;
        public ApplicantCommandHandler(AppDbContext db) => _db = db;

        public async Task<ApplicantDto> Handle(CreateApplicantCommand cmd, CancellationToken ct = default)
        {
            var entity = new Applicant(cmd.Name, cmd.Email, cmd.ExperienceYears);
            _db.Applicants.Add(entity);
            await _db.SaveChangesAsync(ct);
            return new ApplicantDto(entity.Id, entity.Name, entity.Email, entity.ExperienceYears);
        }
    }

    public class ApplicantQueryHandler
    {
        private readonly AppDbContext _db;
        public ApplicantQueryHandler(AppDbContext db) => _db = db;

        public async Task<List<ApplicantDto>> Handle(GetApplicantsQuery query, CancellationToken ct = default)
        {
            return await _db.Applicants
                .Select(a => new ApplicantDto(a.Id, a.Name, a.Email, a.ExperienceYears))
                .ToListAsync(ct);
        }
    }
}