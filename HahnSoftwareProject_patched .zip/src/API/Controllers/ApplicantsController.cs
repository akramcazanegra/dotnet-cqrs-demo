using Application.Commands;
using Application.Handlers;
using Application.Queries;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ApplicantsController : ControllerBase
    {
        private readonly ApplicantCommandHandler _cmd;
        private readonly ApplicantQueryHandler _qry;
        public ApplicantsController(ApplicantCommandHandler cmd, ApplicantQueryHandler qry)
        {
            _cmd = cmd; _qry = qry;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll(CancellationToken ct) =>
            Ok(await _qry.Handle(new GetApplicantsQuery(), ct));

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateApplicantCommand command, CancellationToken ct)
        {
            var created = await _cmd.Handle(command, ct);
            return CreatedAtAction(nameof(GetAll), new { id = created.Id }, created);
        }
    }
}