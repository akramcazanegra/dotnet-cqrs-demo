using MediatR;
using Application.Commands;
using Application.Handlers;
using Application.Queries;
using Application.Validators;
using FluentValidation;
using FluentValidation.AspNetCore;
using Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;


// CORS for dev frontend
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
        policy.AllowAnyHeader()
              .AllowAnyMethod()
              .WithOrigins("http://localhost:5173", "http://localhost:3000"));
});

var builder = WebApplication.CreateBuilder(args);


// MediatR for CQRS handlers
builder.Services.AddMediatR(typeof(Program));
// Add services
builder.Services.AddControllers().AddFluentValidation();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// EF Core (SQL Server)
var conn = builder.Configuration.GetConnectionString("DefaultConnection") 
           ?? "Server=(localdb)\\mssqllocaldb;Database=HahnApplicantsDb;Trusted_Connection=True;MultipleActiveResultSets=true";
builder.Services.AddDbContext<AppDbContext>(opt => opt.UseSqlServer(conn));

// CQRS handlers
builder.Services.AddScoped<ApplicantCommandHandler>();
builder.Services.AddScoped<ApplicantQueryHandler>();

// Validators
builder.Services.AddTransient<IValidator<CreateApplicantCommand>, CreateApplicantValidator>();


app.UseCors();
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.MapControllers();

app.Run();